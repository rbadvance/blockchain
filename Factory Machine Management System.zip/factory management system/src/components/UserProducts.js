import React from 'react'
import UserProductsData from './UserProductsData'

function UserProducts() {
  return (
   <>
    <div className='header'>
      <div className='text'>My Products Place</div>
    </div>
      <UserProductsData />
   </>
  )
}

export default UserProducts